from django.apps import AppConfig


class TravelWishlistConfig(AppConfig):
    name = 'travel_wishlist'
